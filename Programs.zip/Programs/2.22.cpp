//2.22:: Print the code.

#include<iostream>
using namespace std;
int main(){
	cout<<"*\n**\n***\n****\n*****"<<endl;	
	//It prints like below.
	// *
	// **
	// ***
	// ****
	// *****
}
