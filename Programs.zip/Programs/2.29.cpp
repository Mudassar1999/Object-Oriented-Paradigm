//2.29:: Make a table.

#include<iostream>
using namespace std;
int main(){
	cout<<"integer\tsquare\tcube\n";
	for(int a=1;a<=10;a++){
		cout<<a<<"\t"<<a*a<<"\t"<<a*a*a<<"\n";
	}
}
