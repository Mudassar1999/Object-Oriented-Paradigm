//2.17:: Write a program that prints the characters V to Z on the same line with each pair of adjacent characters separated by one space i.e. VXYZ.

#include <iostream>
using namespace std;
int main(){
	cout<<"---------PART a----------";
	cout<<"\n\n"<<"VX"<<" YZ";
	cout<<"\n\n"<<"---------PART b----------"<<"\n\n";
	cout<<"V"<<"X"<<" Y"<<"Z";
	cout<<"\n\n"<<"---------PART c----------"<<"\n\n";
	cout<<"VX YZ";
	cout<<"\n\n\n";
}

