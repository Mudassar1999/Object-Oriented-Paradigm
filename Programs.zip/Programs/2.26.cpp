//Display this code.

#include<iostream>
using namespace std;
int main(){
	for(int a=1;a<=4;a++){

	cout<<"* * * * * * *\n";
	cout<<" * * * * * * *\n";
}
}
