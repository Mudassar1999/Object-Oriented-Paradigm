//2.21:: Display Large Letters.

#include <iostream>
using namespace std;
int main()
{
	cout<<"\n\n^^^^^^^^^^^^AND MY PRESENTATION IS BELOW^^^^^^^^^^^\n\n\n"<<endl;
	cout<<"---------------------------------\n";
	cout<<"\n\t\t\t\t+";
	cout<<"\n\t\t\t\t+"<<endl;
   cout<<  "    ***"<<"\t     *"<<"\t     *"<<"\t\t+";
   cout<<"\n  *"<<"\t     *"<<"\t     *"<<"\t\t+";
   cout<<"\n *"<<"\t   *****"<<"   *****"<<"\t+";
   cout<<"\n  *"<<"\t     *"<<"\t     *"<<"\t\t+";
   cout<<"\n    ***"<<"\t     *"<<"\t     *"<<"\t\t+";
   cout<<"\n\t\t\t\t+";
   cout<<"\n\t\t\t\t+";
   cout<<"\n\t\t\t\t+";
   
   
}
