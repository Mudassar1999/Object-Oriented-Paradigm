//2.27:: Integer equivalent of character.
#include<iostream>
using namespace std;
int main(){
 	char a;
	cout<<"Enter an integer = ";
	cin>>a;
	cout<<static_cast<int>(a)<<" is the ASCII of "<<a;

}
